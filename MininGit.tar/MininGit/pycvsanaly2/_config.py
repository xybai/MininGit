PACKAGE = 'cvsanaly2'
VERSION = '2.3.0'

AUTHOR = 'LibreSoft'
AUTHOR_EMAIL = 'libresoft-tools-devel@lists.morfeo-project.org'
COPYRIGHT = "Copyright (C) 2004-2011 %s <%s>" % (AUTHOR, AUTHOR_EMAIL)
DESCRIPTION = "An analysis tool for your source code repository"
